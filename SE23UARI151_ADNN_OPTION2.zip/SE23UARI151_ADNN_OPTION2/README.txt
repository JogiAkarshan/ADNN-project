Akarshan Jogi, SE23UARI151
Group G_151 (Individual Submission)
Course: CS4125 Advanced Deep Neural Networks (ADNN), Mahindra University
Project: Option 2 - Does Model Collapse Hit Indian Languages First?

Folder layout:

Report.pdf                 final PDF report (Times New Roman 12pt, tables + plots)
Report.html                HTML source used to generate Report.pdf
README.txt                 setup and run instructions
requirements.txt           Python package versions used on my laptop
code/
  get_wiki.py              downloads Wikipedia 20231101 snapshot samples (en, hi, mr, te)
  text_rules.py            Unicode NFC, script purity, markup removal, sentence split
  clean_data.py            builds article-level train, test, and fresh-real splits
  bpe.py                   per-language BPE tokenizer and fertility counter
  model.py                 3-layer causal Transformer (TinyGPT) and top-p sampler
  run_all.py               runs main regimes, fresh control, mixes, fertility, ablations
  analyse.py               computes summary tables, OLS regression, Spearman CI
  plot_results.py          generates all PNG plots into plots/ and results/figures/
plots/                     all 8 PNG plots generated from results/runs.csv
data/
  raw/                     downloaded Wikipedia 20231101 JSONL files
  clean/                   3,000-word D0 train sets, held-out test sets, fresh1..3, clean_log.txt
  tokenizers/              frozen BPE tokenizers (v300, v700, v1400)
results/
  runs.csv                 raw metrics for all 194 model generations
  config_used.txt          exact hyperparameters and seeds
  tables/                  collapse_rates.txt, curves.txt, regression.txt, fertility.txt, safe_fraction.txt, ablation.txt
  figures/                 copy of all PNG plots
  samples/                 saved continuations per generation (marked as model-generated)
  synth/                   synthetic training corpora passed from generation k to k+1
slides/                    15-minute presentation (Slides.pptx, slides.pdf, slides.html, talk.txt)
notes/                     literature reading notes, scope notes, contribution log


How to regenerate all summary tables and plots from results/runs.csv (~5 seconds):

python code/analyse.py
python code/plot_results.py


How to run the full pipeline from scratch:

python code/get_wiki.py
python code/clean_data.py
python code/run_all.py smoke
python code/run_all.py all
python code/analyse.py
python code/plot_results.py


Data note:
Every file in results/samples/ and results/synth/ starts with a warning header marking it as model-generated text rather than real human writing. Source text comes from Hugging Face wikimedia/wikipedia snapshot 20231101 (CC BY-SA 3.0 / GFDL).
