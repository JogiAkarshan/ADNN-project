# Akarshan Jogi, SE23UARI151

import csv
import math
from collections import defaultdict
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
CSV_PATH = ROOT / "results" / "runs.csv"
FIG = ROOT / "results" / "figures"
PLOTS = ROOT / "plots"
FIG.mkdir(parents=True, exist_ok=True)
PLOTS.mkdir(parents=True, exist_ok=True)

LANGS = ["en", "hi", "mr", "te"]
LABEL = {"en": "English", "hi": "Hindi", "mr": "Marathi", "te": "Telugu"}
COLOR = {"en": "black", "hi": "#1f77b4", "mr": "#2ca02c", "te": "#d62728"}


def load_rows():
    rows = []
    with open(CSV_PATH, "r", encoding="utf-8") as f:
        for r in csv.DictReader(f):
            try:
                r["generation"] = int(float(r["generation"]))
                r["seed"] = int(float(r["seed"]))
                r["value"] = float(r["value"])
            except Exception:
                continue
            rows.append(r)
    return rows


def main_mask(r):
    try:
        return (
            int(r["filter"]) == 0
            and abs(float(r["temp"]) - 1.0) < 1e-6
            and int(r["prompt_words"]) == 16
            and int(r["layers"]) == 3
        )
    except Exception:
        return False


def series(rows, regime, metric, frac=None):
    bag = defaultdict(list)
    for r in rows:
        if not main_mask(r):
            continue
        if r["regime"] != regime or r["metric"] != metric:
            continue
        if frac is not None and str(r["fraction"]) != str(frac):
            continue
        bag[(r["language"], r["generation"])].append(r["value"])
    out = {}
    for (lang, gen), vals in bag.items():
        m = sum(vals) / float(len(vals))
        out.setdefault(lang, {})[gen] = m
    return out


def main_vocab_by_lang(rows):
    counts = defaultdict(int)
    for r in rows:
        if r["regime"] == "replace" and r["metric"] == "bpc" and r["generation"] == 0 and main_mask(r):
            counts[(r["language"], r["vocab"])] += 1
    chosen = {}
    for lang in LANGS:
        options = [(v, c) for (l, v), c in counts.items() if l == lang]
        if not options:
            continue
        options.sort(key=lambda t: -t[1])
        chosen[lang] = options[0][0]
    return chosen


def series_vocab(rows, regime, metric, vocab_of, word_budget):
    bag = defaultdict(list)
    for r in rows:
        if not main_mask(r):
            continue
        if r["regime"] != regime or r["metric"] != metric:
            continue
        if vocab_of.get(r["language"]) != str(r["vocab"]):
            continue
        if word_budget is not None and int(float(r["words"])) != int(word_budget):
            continue
        bag[(r["language"], r["generation"])].append(r["value"])
    out = {}
    for (lang, gen), vals in bag.items():
        out.setdefault(lang, {})[gen] = sum(vals) / float(len(vals))
    return out


def rel(by_gen):
    if 0 not in by_gen or by_gen[0] == 0:
        return {}
    base = by_gen[0]
    return {g: (by_gen[g] - base) / abs(base) for g in by_gen}


def word_budget_of(rows):
    vals = []
    for r in rows:
        if r["metric"] == "bpc" and r["seed"] == 152 and r["regime"] == "replace":
            vals.append(int(float(r["words"])))
    return max(vals) if vals else None


def plot_rel(rows, regime, metric, filename, ylabel, title, vocab_of, word_budget):
    data = series_vocab(rows, regime, metric, vocab_of, word_budget)
    plt.figure(figsize=(6.2, 4.0))
    for lang in LANGS:
        if lang not in data:
            continue
        rr = rel(data[lang])
        gs = sorted(rr)
        plt.plot(gs, [rr[g] for g in gs], marker="o", color=COLOR[lang], label=LABEL[lang])
    plt.axhline(0, color="grey", linewidth=0.8)
    plt.xlabel("generation")
    plt.ylabel(ylabel)
    plt.title(title)
    plt.legend()
    plt.tight_layout()
    plt.savefig(FIG / filename, dpi=140)
    plt.savefig(PLOTS / filename, dpi=140)
    plt.close()


def plot_raw(rows, regime, metric, filename, ylabel, title, vocab_of, word_budget):
    data = series_vocab(rows, regime, metric, vocab_of, word_budget)
    plt.figure(figsize=(6.2, 4.0))
    for lang in LANGS:
        if lang not in data:
            continue
        gs = sorted(data[lang])
        plt.plot(gs, [data[lang][g] for g in gs], marker="o", color=COLOR[lang], label=LABEL[lang])
    plt.xlabel("generation")
    plt.ylabel(ylabel)
    plt.title(title)
    plt.legend()
    plt.tight_layout()
    plt.savefig(FIG / filename, dpi=140)
    plt.savefig(PLOTS / filename, dpi=140)
    plt.close()


def plot_fertility(rows, word_budget):
    pts = defaultdict(list)
    for r in rows:
        if r["regime"] != "replace" or not main_mask(r):
            continue
        if word_budget is not None and int(float(r["words"])) != int(word_budget):
            continue
        if r["metric"] == "fertility" and r["generation"] == 0 and r["seed"] == 151:
            pts[(r["language"], r["vocab"])].append(("f", r["value"]))
        if r["metric"] == "bpc" and r["seed"] == 151:
            pts[(r["language"], r["vocab"])].append((r["generation"], r["value"]))
    xs, ys, labels = [], [], []
    for (lang, vocab), items in pts.items():
        fert = None
        bpc = {}
        for a, b in items:
            if a == "f":
                fert = b
            else:
                bpc[a] = b
        if fert is None or 0 not in bpc or len(bpc) < 3:
            continue
        gs = sorted(bpc)
        import numpy as np
        base = bpc[0]
        rels = [(bpc[g] - base) / abs(base) for g in gs]
        slope = float(np.polyfit(gs, rels, 1)[0])
        xs.append(fert)
        ys.append(slope)
        labels.append(LABEL.get(lang, lang) + " " + str(vocab))
    if not xs:
        return
    plt.figure(figsize=(6.2, 4.0))
    plt.scatter(xs, ys, color="#1f77b4")
    offsets = {
        "Hindi 700": (-14, -12),
        "English 700": (5, 5),
        "Telugu 700": (5, -10),
        "Telugu 300": (-48, -10),
    }
    for x, y, lab in zip(xs, ys, labels):
        dx, dy = offsets.get(lab, (4, 4))
        plt.annotate(lab, (x, y), textcoords="offset points", xytext=(dx, dy), fontsize=8)
    plt.margins(x=0.14, y=0.14)
    plt.xlabel("fertility (tokens per word on real text)")
    plt.ylabel("bpc collapse slope")
    plt.title("Does fertility line up with collapse?")
    plt.tight_layout()
    plt.savefig(FIG / "fertility_vs_collapse.png", dpi=140)
    plt.savefig(PLOTS / "fertility_vs_collapse.png", dpi=140)
    plt.close()


def main():
    rows = load_rows()
    vocab_of = main_vocab_by_lang(rows)
    budget = word_budget_of(rows)
    plot_rel(rows, "replace", "bpc", "replace_bpc_relative.png",
             "change in bits/char vs generation 0", "Replace: bits per character, relative to generation 0", vocab_of, budget)
    plot_rel(rows, "accumulate", "bpc", "accumulate_bpc_relative.png",
             "change in bits/char vs generation 0", "Accumulate: bits per character, relative to generation 0", vocab_of, budget)
    plot_raw(rows, "replace", "tail_retention", "tail_retention_replace.png",
             "fraction of rare D0 words still seen", "Replace: rare-word retention", vocab_of, budget)
    plot_raw(rows, "accumulate", "tail_retention", "tail_retention_accumulate.png",
             "fraction of rare D0 words still seen", "Accumulate: rare-word retention", vocab_of, budget)
    plot_raw(rows, "replace", "script_purity", "script_purity_replace.png",
             "fraction of letters in the target script", "Replace: script purity", vocab_of, budget)
    plot_raw(rows, "replace", "distinct1", "distinct1_replace.png",
             "unique words / total words", "Replace: distinct-1 on generated text", vocab_of, budget)
    plot_raw(rows, "replace", "wordlen_js", "wordlen_js_replace.png",
             "JS distance of word lengths vs real text", "Replace: word-length shift", vocab_of, budget)
    plot_fertility(rows, budget)
    print("figures in", FIG)


if __name__ == "__main__":
    main()
