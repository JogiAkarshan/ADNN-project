# Akarshan Jogi, SE23UARI151

import re
import unicodedata

SCRIPTS = {
    "en": ("latin",),
    "hi": ("devanagari",),
    "mr": ("devanagari",),
    "te": ("telugu",),
}

STOP_HEADS = [
    "references", "see also", "external links", "further reading",
    "notes", "bibliography", "sources", "footnotes",
    "सन्दर्भ", "संदर्भ", "इन्हें भी देखें", "बाहरी कड़ियाँ", "बाहरी कड़ियां",
    "आगे पढ़ें", "टिप्पणी", "स्रोत",
    "हे सुद्धा पहा", "बाह्य दुवे", "संदर्भ", "नोट्स", "आणखी वाचा",
    "మూలాలు", "మూలం", "ఇవి కూడా చూడండి", "బయటి లింకులు", "వనరులు",
    "గమనికలు", "మరింత చదవండి",
]


def is_latin(ch):
    return ("A" <= ch <= "Z") or ("a" <= ch <= "z")


def is_devanagari(ch):
    return "\u0900" <= ch <= "\u097F"


def is_telugu(ch):
    return "\u0C00" <= ch <= "\u0C7F"


def letter_kind(ch):
    if is_latin(ch):
        return "latin"
    if is_devanagari(ch):
        return "devanagari"
    if is_telugu(ch):
        return "telugu"
    if ch.isalpha():
        return "other"
    return None


def nfc(text):
    return unicodedata.normalize("NFC", text)


def script_fraction(text, lang):
    want = SCRIPTS[lang]
    total = 0
    good = 0
    for ch in text:
        kind = letter_kind(ch)
        if kind is None:
            continue
        total += 1
        if kind in want:
            good += 1
    if total == 0:
        return 0.0
    return good / float(total)


def mostly_target_script(text, lang, cutoff=0.80):
    letters = 0
    for ch in text:
        if letter_kind(ch) is not None:
            letters += 1
    if letters < 8:
        return False
    return script_fraction(text, lang) >= cutoff


def _is_stop_head(line):
    t = line.strip().strip("=").strip().lower()
    if not t:
        return False
    for h in STOP_HEADS:
        if t == h.lower():
            return True
    return False


def strip_article(text):
    text = nfc(text)
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    text = text.replace("\u00a0", " ")
    kept = []
    for line in text.split("\n"):
        raw = line.strip()
        if not raw:
            continue
        if _is_stop_head(raw):
            break
        if raw.startswith("=="):
            continue
        if "http://" in raw or "https://" in raw:
            continue
        if raw.count("|") >= 2 or raw.count("{") >= 2:
            continue
        if "<ref" in raw or "[[" in raw or "]]" in raw:
            continue
        kept.append(raw)
    return "\n".join(kept)


def split_sentences(text, lang):
    text = re.sub(r"\s+", " ", text).strip()
    if not text:
        return []
    if lang == "en":
        parts = re.split(r"(?<=[.!?])\s+", text)
    else:
        parts = re.split(r"(?<=[।!?])\s+|(?<=\.)\s+", text)
    out = []
    for p in parts:
        p = p.strip()
        if p:
            out.append(p)
    return out


def word_count(text):
    return len(text.split())


def take_words(text, n):
    words = text.split()
    if len(words) <= n:
        return " ".join(words)
    return " ".join(words[:n])


def latin_word_rate(text):
    words = text.split()
    if not words:
        return 0.0
    latin = 0
    for w in words:
        letters = [ch for ch in w if ch.isalpha()]
        if not letters:
            continue
        if all(is_latin(ch) for ch in letters):
            latin += 1
    return latin / float(len(words))
