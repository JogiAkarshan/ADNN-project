# Akarshan Jogi, SE23UARI151

import json
import sys
import time
import urllib.parse
import urllib.request
from pathlib import Path

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / "data" / "raw"
RAW.mkdir(parents=True, exist_ok=True)

TARGETS = {"en": 22000, "hi": 12000, "mr": 12000, "te": 22000}
COUNT_CAP = 700
CONFIG = {
    "en": "20231101.en",
    "hi": "20231101.hi",
    "mr": "20231101.mr",
    "te": "20231101.te",
}
UA = "ADNN-course-project/1.0 (Akarshan Jogi, SE23UARI151; university assignment)"
BASE = "https://datasets-server.huggingface.co/rows"


def words(text):
    return len(text.split())


def get_json(url):
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    last = None
    for attempt in range(6):
        try:
            with urllib.request.urlopen(req, timeout=90) as resp:
                return json.loads(resp.read().decode("utf-8"))
        except Exception as e:
            last = e
            wait = 8.0 * (attempt + 1)
            print("  retry in %.0fs (%s)" % (wait, e), flush=True)
            time.sleep(wait)
    raise RuntimeError(str(last))


def first_total(lang):
    q = urllib.parse.urlencode({
        "dataset": "wikimedia/wikipedia",
        "config": CONFIG[lang],
        "split": "train",
        "offset": "0",
        "length": "1",
    })
    data = get_json(BASE + "?" + q)
    return int(data["num_rows_total"])


def fetch_offset(lang, offset, length):
    q = urllib.parse.urlencode({
        "dataset": "wikimedia/wikipedia",
        "config": CONFIG[lang],
        "split": "train",
        "offset": str(offset),
        "length": str(length),
    })
    data = get_json(BASE + "?" + q)
    rows = []
    for item in data.get("rows", []):
        row = item.get("row") or {}
        text = row.get("text") or ""
        if words(text) < 80:
            continue
        rows.append({
            "pageid": row.get("id"),
            "title": row.get("title") or "",
            "url": row.get("url") or "",
            "text": text,
            "snapshot": "wikimedia/wikipedia " + CONFIG[lang],
        })
    return rows


def collect(lang, target):
    path = RAW / (lang + ".jsonl")
    tmp = RAW / (lang + ".jsonl.tmp")
    total_rows = first_total(lang)
    print("%s snapshot rows %d, target words %d" % (lang, total_rows, target), flush=True)
    got = 0
    seen = set()
    n_calls = 36
    length = 4
    with open(tmp, "w", encoding="utf-8") as f:
        for i in range(n_calls):
            if got >= target:
                break
            offset = int((i + 0.3) / float(n_calls) * max(1, total_rows - length))
            try:
                batch = fetch_offset(lang, offset, length)
            except Exception as e:
                print("  warn", lang, "offset", offset, e, flush=True)
                continue
            added = 0
            for row in batch:
                pid = str(row["pageid"])
                if pid in seen:
                    continue
                seen.add(pid)
                f.write(json.dumps(row, ensure_ascii=False) + "\n")
                w = words(row["text"])
                got += w if w < COUNT_CAP else COUNT_CAP
                added += 1
            f.flush()
            print("  %s call %d offset %d +%d words %d" % (lang, i + 1, offset, added, got), flush=True)
            time.sleep(0.4)
            if got >= target:
                break
    if got < 4000:
        print("done", lang, "TOO SMALL", got, "keeping any older file", flush=True)
        return got
    tmp.replace(path)
    print("done", lang, "words", got, "pages", len(seen), flush=True)
    return got


def main():
    langs = sys.argv[1:] if len(sys.argv) > 1 else list(TARGETS.keys())
    for lang in langs:
        collect(lang, TARGETS[lang])


if __name__ == "__main__":
    main()
