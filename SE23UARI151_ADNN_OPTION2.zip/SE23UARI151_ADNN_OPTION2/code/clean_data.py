# Akarshan Jogi, SE23UARI151

import json
import random
from pathlib import Path

from text_rules import (
    mostly_target_script,
    split_sentences,
    strip_article,
    word_count,
)

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / "data" / "raw"
CLEAN = ROOT / "data" / "clean"
CLEAN.mkdir(parents=True, exist_ok=True)

LANGS = ["en", "hi", "mr", "te"]
SPLIT_SEED = 151
MAX_WORDS_PER_ARTICLE = 500
BUDGET_CAP = 3000
TEST_CAP = 1000


def clip_to_words(sentences, n):
    out = []
    got = 0
    for s in sentences:
        w = s.split()
        if not w:
            continue
        if got + len(w) <= n:
            out.append(s)
            got += len(w)
            continue
        need = n - got
        if need > 0:
            out.append(" ".join(w[:need]))
            got += need
        break
    return out, got


def clean_language(lang, log):
    path = RAW / (lang + ".jsonl")
    if not path.exists():
        raise SystemExit("missing " + str(path) + "  (run get_wiki.py first)")
    seen_sent = set()
    articles = []
    n_pages = 0
    drop_script = 0
    drop_short = 0
    drop_dup = 0
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            n_pages += 1
            row = json.loads(line)
            body = strip_article(row.get("text") or "")
            sents = split_sentences(body, lang)
            kept = []
            used = 0
            for s in sents:
                if word_count(s) < 5:
                    drop_short += 1
                    continue
                if not mostly_target_script(s, lang, 0.80):
                    drop_script += 1
                    continue
                key = s
                if key in seen_sent:
                    drop_dup += 1
                    continue
                if used >= MAX_WORDS_PER_ARTICLE:
                    break
                room = MAX_WORDS_PER_ARTICLE - used
                w = s.split()
                if len(w) > room:
                    s = " ".join(w[:room])
                    w = s.split()
                seen_sent.add(key)
                kept.append(s)
                used += len(w)
            if kept:
                articles.append({"title": row.get("title") or "", "sentences": kept})
    log.append(
        "%s pages=%d articles_kept=%d drop_short=%d drop_script=%d drop_dup=%d"
        % (lang, n_pages, len(articles), drop_short, drop_script, drop_dup)
    )
    return articles


def write_sents(path, sentences):
    with open(path, "w", encoding="utf-8") as f:
        for s in sentences:
            f.write(s + "\n")


def main():
    log = []
    log.append("split seed %d" % SPLIT_SEED)
    log.append("rules: NFC; cut at references/see-also headings; drop urls, tables, wiki markup;")
    log.append("drop sentences under 5 words; drop sentences with under 80% letters in the target script;")
    log.append("dedupe exact sentences; cap each article at %d words." % MAX_WORDS_PER_ARTICLE)
    log.append("script check is on letters only (spaces, digits, punctuation ignored).")
    cleaned = {}
    for lang in LANGS:
        cleaned[lang] = clean_language(lang, log)

    rng = random.Random(SPLIT_SEED)
    pools = {}
    for lang in LANGS:
        arts = list(cleaned[lang])
        rng.shuffle(arts)
        test_arts = []
        train_arts = []
        test_words = 0
        max_test = max(2, int(0.25 * len(arts)))
        for a in arts:
            aw = sum(word_count(s) for s in a["sentences"])
            if (test_words < 500 or len(test_arts) < 2) and len(test_arts) < max_test:
                test_arts.append(a)
                test_words += aw
            else:
                train_arts.append(a)
        n_test = len(test_arts)
        test_sents = []
        for a in test_arts:
            test_sents.extend(a["sentences"])
        train_sents = []
        for a in train_arts:
            train_sents.extend(a["sentences"])
        pools[lang] = {"test": test_sents, "train": train_sents, "n_test_arts": n_test, "n_train_arts": len(train_arts)}
        log.append(
            "%s train_articles=%d train_words=%d test_articles=%d test_words=%d"
            % (
                lang,
                len(train_arts),
                sum(word_count(s) for s in train_sents),
                n_test,
                sum(word_count(s) for s in test_sents),
            )
        )

    budgets = []
    for lang in LANGS:
        budgets.append(sum(word_count(s) for s in pools[lang]["train"]))
    budget = min(budgets)
    if budget > BUDGET_CAP:
        budget = BUDGET_CAP
    log.append("word budget used for every language: %d" % budget)
    log.append("(cap is %d; the smallest cleaned train pool was %d)" % (BUDGET_CAP, min(budgets)))

    for lang in LANGS:
        train_sents, n_tr = clip_to_words(pools[lang]["train"], budget)
        test_sents, n_te = clip_to_words(pools[lang]["test"], TEST_CAP)
        write_sents(CLEAN / (lang + "_train.txt"), train_sents)
        write_sents(CLEAN / (lang + "_test.txt"), test_sents)
        log.append("%s saved train_words=%d test_words=%d" % (lang, n_tr, n_te))

        if lang in ("en", "te"):
            used = n_tr
            left = []
            got = 0
            for s in pools[lang]["train"]:
                w = word_count(s)
                if got + w <= used and got < used:
                    got += w
                    continue
                if got < used:
                    ww = s.split()
                    take = used - got
                    rest = ww[take:]
                    got = used
                    if rest:
                        left.append(" ".join(rest))
                    continue
                left.append(s)
            made = 0
            for k in (1, 2, 3):
                chunk, n_ck = clip_to_words(left, budget)
                take_n = n_ck
                new_left = []
                seen = 0
                for s in left:
                    w = s.split()
                    if seen >= take_n:
                        new_left.append(s)
                        continue
                    if seen + len(w) <= take_n:
                        seen += len(w)
                        continue
                    rest = w[take_n - seen:]
                    seen = take_n
                    if rest:
                        new_left.append(" ".join(rest))
                left = new_left
                if n_ck < int(budget * 0.8):
                    log.append("%s fresh%d NOT enough words (%d), skipped" % (lang, k, n_ck))
                    break
                write_sents(CLEAN / ("%s_fresh%d.txt" % (lang, k)), chunk)
                log.append("%s fresh%d words=%d" % (lang, k, n_ck))
                made += 1
            log.append("%s fresh chunks written: %d" % (lang, made))

    with open(CLEAN / "budget.txt", "w", encoding="utf-8") as f:
        f.write(str(budget) + "\n")
    with open(CLEAN / "clean_log.txt", "w", encoding="utf-8") as f:
        f.write("\n".join(log) + "\n")
    print("\n".join(log))


if __name__ == "__main__":
    main()
