# Akarshan Jogi, SE23UARI151

from collections import Counter

END = "\uE000"


class BPE(object):
    def __init__(self, merges, token_to_id):
        self.merges = merges
        self.rank = {}
        for i, pair in enumerate(merges):
            self.rank[pair] = i
        self.token_to_id = token_to_id
        self.id_to_token = [None] * len(token_to_id)
        for t, i in token_to_id.items():
            self.id_to_token[i] = t
        self.unk_id = token_to_id["<unk>"]
        self.pad_id = token_to_id["<pad>"]

    @property
    def vocab_size(self):
        return len(self.token_to_id)

    def _merge_word(self, symbols):
        while len(symbols) >= 2:
            best = None
            best_rank = None
            for i in range(len(symbols) - 1):
                pair = (symbols[i], symbols[i + 1])
                r = self.rank.get(pair)
                if r is None:
                    continue
                if best_rank is None or r < best_rank:
                    best_rank = r
                    best = i
            if best is None:
                break
            a = symbols[best]
            b = symbols[best + 1]
            symbols = symbols[:best] + [a + b] + symbols[best + 2:]
        return symbols

    def encode_word(self, word):
        symbols = list(word) + [END]
        symbols = self._merge_word(symbols)
        ids = []
        for s in symbols:
            ids.append(self.token_to_id.get(s, self.unk_id))
        return ids

    def encode(self, text):
        ids = []
        for w in text.split():
            if not w:
                continue
            ids.extend(self.encode_word(w))
        return ids

    def decode(self, ids):
        parts = []
        for i in ids:
            if i < 0 or i >= len(self.id_to_token):
                continue
            tok = self.id_to_token[i]
            if tok in ("<pad>", "<unk>", None):
                continue
            parts.append(tok)
        text = "".join(parts).replace(END, " ")
        return " ".join(text.split())

    def fertility(self, text):
        words = text.split()
        if not words:
            return 0.0
        pieces = 0
        for w in words:
            symbols = self._merge_word(list(w) + [END])
            for s in symbols:
                if s != END:
                    pieces += 1
        return pieces / float(len(words))

    def save(self, path):
        lines = []
        items = sorted(self.token_to_id.items(), key=lambda kv: kv[1])
        lines.append("TOKENS")
        for t, i in items:
            lines.append(str(i) + "\t" + t)
        lines.append("MERGES")
        for a, b in self.merges:
            lines.append(a + "\t" + b)
        with open(path, "w", encoding="utf-8") as f:
            f.write("\n".join(lines))

    @staticmethod
    def load(path):
        token_to_id = {}
        merges = []
        mode = None
        with open(path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.rstrip("\n")
                if line == "TOKENS":
                    mode = "t"
                    continue
                if line == "MERGES":
                    mode = "m"
                    continue
                if not line:
                    continue
                if mode == "t":
                    i, t = line.split("\t", 1)
                    token_to_id[t] = int(i)
                elif mode == "m":
                    a, b = line.split("\t", 1)
                    merges.append((a, b))
        return BPE(merges, token_to_id)


def train_bpe(texts, vocab_size):
    if isinstance(texts, list):
        words = []
        for t in texts:
            words.extend(t.split())
    else:
        words = texts.split()
    corpus = []
    char_counts = Counter()
    for w in words:
        symbols = list(w) + [END]
        corpus.append(symbols)
        for s in symbols:
            char_counts[s] += 1

    base = ["<pad>", "<unk>"] + sorted(char_counts.keys())
    merges = []
    target_merges = max(0, vocab_size - len(base))

    def pair_counts(corpus):
        c = Counter()
        for symbols in corpus:
            for i in range(len(symbols) - 1):
                c[(symbols[i], symbols[i + 1])] += 1
        return c

    for _ in range(target_merges):
        counts = pair_counts(corpus)
        if not counts:
            break
        pair, n = counts.most_common(1)[0]
        if n < 2:
            break
        merges.append(pair)
        a, b = pair
        merged = a + b
        new_corpus = []
        for symbols in corpus:
            out = []
            i = 0
            while i < len(symbols):
                if i < len(symbols) - 1 and symbols[i] == a and symbols[i + 1] == b:
                    out.append(merged)
                    i += 2
                else:
                    out.append(symbols[i])
                    i += 1
            new_corpus.append(out)
        corpus = new_corpus

    token_to_id = {}
    for i, t in enumerate(base):
        token_to_id[t] = i
    next_id = len(base)
    for a, b in merges:
        tok = a + b
        if tok not in token_to_id:
            token_to_id[tok] = next_id
            next_id += 1
    return BPE(merges, token_to_id)
