# Akarshan Jogi, SE23UARI151

import csv
import math
import os
import random
import sys
import time
from collections import Counter
from pathlib import Path

os.environ.setdefault("OMP_NUM_THREADS", "8")
os.environ.setdefault("MKL_NUM_THREADS", "8")

import torch
import torch.nn.functional as F

from bpe import train_bpe
from model import TinyGPT, sample_top_p
from text_rules import latin_word_rate, mostly_target_script, script_fraction, take_words, word_count

ROOT = Path(__file__).resolve().parents[1]
CLEAN = ROOT / "data" / "clean"
RES = ROOT / "results"
SYN = RES / "synth"
SAMP = RES / "samples"
TOKDIR = ROOT / "data" / "tokenizers"
for p in (RES, SYN, SAMP, TOKDIR):
    p.mkdir(parents=True, exist_ok=True)

N_EMBD = 96
N_HEAD = 4
N_LAYER = 3
BLOCK = 64
BATCH = 24
LR = 3e-3
EPOCHS = 8
MIN_STEPS_PER_EPOCH = 50
VOCAB = 700
TEMP = 1.0
TOP_P = 0.95
MAX_NEW = 128
PROMPT_WORDS = 16
SEG_WORDS = 40
GENS = 6
SEEDS = [151, 152]
LANGS = ["en", "hi", "mr", "te"]
SETTING = "B"

CSV_PATH = RES / "runs.csv"
DONE_PATH = RES / "done.txt"
FAIL_PATH = RES / "failed.txt"


def log(msg):
    print(msg, flush=True)


def load_budget():
    return int((CLEAN / "budget.txt").read_text(encoding="utf-8").strip())


def load_sents(path):
    text = path.read_text(encoding="utf-8")
    return [ln.strip() for ln in text.splitlines() if ln.strip()]


def sents_to_text(sents):
    return "\n".join(sents)


def read_done():
    if not DONE_PATH.exists():
        return set()
    return set(x.strip() for x in DONE_PATH.read_text(encoding="utf-8").splitlines() if x.strip())


def mark_done(key):
    with open(DONE_PATH, "a", encoding="utf-8") as f:
        f.write(key + "\n")


def key_of(lang, regime, frac, gen, seed, vocab, temp, do_filter, prompt_words, n_layer, words):
    return "B_%s_%s_f%s_g%d_s%d_v%d_t%s_filt%d_p%d_L%d_w%d" % (
        lang, regime, frac, gen, seed, vocab, temp, 1 if do_filter else 0, prompt_words, n_layer, words
    )


def ensure_csv():
    if CSV_PATH.exists():
        return
    with open(CSV_PATH, "w", encoding="utf-8", newline="") as f:
        w = csv.writer(f)
        w.writerow([
            "setting", "language", "regime", "fraction", "generation", "seed",
            "metric", "value", "vocab", "temp", "filter", "prompt_words",
            "layers", "words", "embd",
        ])


def add_rows(lang, regime, frac, gen, seed, metrics, vocab, temp, do_filter, prompt_words, n_layer, words):
    ensure_csv()
    with open(CSV_PATH, "a", encoding="utf-8", newline="") as f:
        w = csv.writer(f)
        for name, value in metrics.items():
            w.writerow([
                SETTING, lang, regime, frac, gen, seed, name, value,
                vocab, temp, int(do_filter), prompt_words, n_layer, words, N_EMBD,
            ])


def get_tokenizer(lang, text, vocab):
    path = TOKDIR / ("%s_v%d.bpe" % (lang, vocab))
    if path.exists():
        from bpe import BPE
        return BPE.load(str(path))
    t0 = time.time()
    tok = train_bpe(text, vocab)
    tok.save(str(path))
    log("  tokenizer %s vocab %d (asked %d) in %.1fs" % (lang, tok.vocab_size, vocab, time.time() - t0))
    return tok


def train_lm(tok, text, seed, gen, n_layer):
    torch.manual_seed(int(seed) * 100 + int(gen))
    random.seed(int(seed) * 100 + int(gen))
    ids = tok.encode(text)
    if len(ids) < BLOCK + 2:
        raise RuntimeError("too few tokens to train (%d)" % len(ids))
    model = TinyGPT(tok.vocab_size, N_EMBD, N_HEAD, n_layer, BLOCK)
    opt = torch.optim.AdamW(model.parameters(), lr=LR, weight_decay=0.01)
    data = torch.tensor(ids, dtype=torch.long)
    n = int(data.numel())
    steps_per = max(MIN_STEPS_PER_EPOCH, (n - BLOCK - 1) // (BATCH * BLOCK))
    steps = EPOCHS * steps_per
    model.train()
    last = 0.0
    t0 = time.time()
    offs = torch.arange(BLOCK)
    for _step in range(steps):
        ix = torch.randint(0, n - BLOCK - 1, (BATCH,))
        x = data[ix.unsqueeze(1) + offs]
        y = data[ix.unsqueeze(1) + offs + 1]
        logits = model(x)
        loss = F.cross_entropy(logits.reshape(-1, tok.vocab_size), y.reshape(-1))
        if torch.isnan(loss):
            raise RuntimeError("loss became nan")
        opt.zero_grad()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        opt.step()
        last = float(loss.item())
    secs = time.time() - t0
    return model, last, len(ids), steps, secs


def sentence_bits(model, tok, sentence):
    ids = tok.encode(sentence)
    if len(ids) < 2:
        return None
    total = 0.0
    model.eval()
    ids_t = torch.tensor(ids, dtype=torch.long)
    with torch.no_grad():
        pos = 0
        while pos < len(ids) - 1:
            end = min(pos + BLOCK, len(ids) - 1)
            x = ids_t[pos:end].unsqueeze(0)
            y = ids_t[pos + 1:end + 1]
            logits = model(x)
            loss = F.cross_entropy(logits.reshape(-1, tok.vocab_size), y, reduction="sum")
            total += float(loss.item())
            pos = end
    return total / math.log(2.0), len(sentence), len(ids) - 1


def bpc_with_ci(model, tok, sentences, seed, gen):
    stats = []
    for s in sentences:
        row = sentence_bits(model, tok, s)
        if row is None:
            continue
        bits, chars, _nt = row
        stats.append((bits, chars))
    if not stats:
        return float("nan"), float("nan"), float("nan"), 0
    bits = sum(b for b, _c in stats)
    chars = sum(c for _b, c in stats)
    point = bits / float(chars)
    rng = random.Random(seed * 1000 + gen + 17)
    n = len(stats)
    boots = []
    for _ in range(1000):
        tb = 0.0
        tc = 0
        for _k in range(n):
            b, c = stats[rng.randrange(n)]
            tb += b
            tc += c
        if tc > 0:
            boots.append(tb / float(tc))
    boots.sort()
    lo = boots[int(0.025 * (len(boots) - 1))]
    hi = boots[int(0.975 * (len(boots) - 1))]
    return point, lo, hi, n


def prompts_from(text, prompt_words):
    words = text.split()
    out = []
    i = 0
    while i + prompt_words <= len(words):
        out.append(" ".join(words[i:i + prompt_words]))
        i += SEG_WORDS
    if not out and words:
        out.append(" ".join(words[:prompt_words]))
    return out


@torch.no_grad()
def generate_text(model, tok, real_text, temp, top_p, prompt_words, target_words, seed, gen):
    torch.manual_seed(int(seed) * 1000 + int(gen) * 13 + 3)
    model.eval()
    prompts = prompts_from(real_text, prompt_words)
    if not prompts:
        raise RuntimeError("no prompts")
    lines = []
    got = 0
    cursor = 0
    t0 = time.time()
    guard = 0
    while got < target_words and guard < 40:
        guard += 1
        batch_ids = []
        for _ in range(16):
            p = prompts[cursor % len(prompts)]
            cursor += 1
            ids = tok.encode(p)
            if len(ids) < 8:
                continue
            batch_ids.append(ids[-32:])
        if not batch_ids:
            break
        L = min(len(b) for b in batch_ids)
        x = torch.tensor([b[-L:] for b in batch_ids], dtype=torch.long)
        for _step in range(MAX_NEW):
            logits = model(x[:, -BLOCK:])[:, -1, :]
            nxt = sample_top_p(logits, temp, top_p)
            x = torch.cat([x, nxt.unsqueeze(1)], dim=1)
        new_part = x[:, L:]
        for row in new_part.tolist():
            text = tok.decode(row)
            text = " ".join(text.split())
            if not text:
                continue
            lines.append(text)
            got += word_count(text)
            if got >= target_words:
                break
    secs = time.time() - t0
    body = "\n".join(lines)
    body = take_words(body.replace("\n", " "), target_words)
    if word_count("\n".join(lines)) <= target_words:
        body = "\n".join(lines)
    return body, secs


def filter_text(text, lang):
    kept = []
    for line in text.split("\n"):
        line = line.strip()
        if not line:
            continue
        if mostly_target_script(line, lang, 0.80):
            kept.append(line)
    seen = set()
    out = []
    for line in kept:
        if line in seen:
            continue
        seen.add(line)
        out.append(line)
    return "\n".join(out)


def word_len_hist(words):
    h = [0] * 40
    for w in words:
        n = len(w)
        if n < 1:
            continue
        if n > 40:
            n = 40
        h[n - 1] += 1
    return h


def js_div(h1, h2):
    s1 = float(sum(h1)) or 1.0
    s2 = float(sum(h2)) or 1.0
    p = [x / s1 for x in h1]
    q = [x / s2 for x in h2]
    eps = 1e-12
    m = [(a + b) / 2.0 for a, b in zip(p, q)]

    def kl(a, b):
        s = 0.0
        for x, y in zip(a, b):
            if x > 0:
                s += x * math.log((x + eps) / (y + eps), 2)
        return s

    return 0.5 * kl(p, m) + 0.5 * kl(q, m)


def char_bigrams(text):
    c = Counter()
    for w in text.split():
        if len(w) < 2:
            continue
        for i in range(len(w) - 1):
            c[w[i:i + 2]] += 1
    return c


def retention(rare_items, sample_items):
    if not rare_items:
        return float("nan")
    sample = set(sample_items)
    hit = 0
    for item in rare_items:
        if item in sample:
            hit += 1
    return hit / float(len(rare_items))


def text_metrics(gen_text, d0_text):
    d0_words = d0_text.split()
    gen_words = gen_text.split()
    sample = gen_words[:len(d0_words)] if d0_words else gen_words
    d1 = 0.0
    d2 = 0.0
    if sample:
        d1 = len(set(sample)) / float(len(sample))
    if len(sample) >= 2:
        pairs = list(zip(sample, sample[1:]))
        d2 = len(set(pairs)) / float(len(pairs))
    d0_counts = Counter(d0_words)
    rare_words = [w for w, c in d0_counts.items() if 2 <= c <= 10]
    tail = retention(rare_words, sample)
    d0_bi = char_bigrams(d0_text)
    rare_bi = [b for b, c in d0_bi.items() if 2 <= c <= 10]
    gen_bi = char_bigrams(" ".join(sample))
    present_bi = [b for b, c in gen_bi.items() if c > 0]
    rare_char = retention(rare_bi, present_bi)
    js = js_div(word_len_hist(d0_words), word_len_hist(sample))
    return {
        "distinct1": d1,
        "distinct2": d2,
        "tail_retention": tail,
        "rare_char_retention": rare_char,
        "wordlen_js": js,
        "script_purity": None,
        "latin_word_rate": latin_word_rate(gen_text),
        "gen_words": word_count(gen_text),
        "rare_word_types": len(rare_words),
        "rare_char_types": len(rare_bi),
    }


def script_sentence_rate(text, lang):
    lines = [ln.strip() for ln in text.splitlines() if ln.strip()]
    if not lines:
        words = text.split()
        lines = []
        for i in range(0, len(words), 20):
            chunk = " ".join(words[i:i + 20])
            if chunk:
                lines.append(chunk)
    if not lines:
        return float("nan")
    ok = 0
    for ln in lines:
        if script_fraction(ln, lang) >= 0.80:
            ok += 1
    return ok / float(len(lines))


def synth_path(key):
    return SYN / (key + ".txt")


def save_text(path, text, header):
    with open(path, "w", encoding="utf-8") as f:
        f.write(header + "\n")
        f.write(text)
        if not text.endswith("\n"):
            f.write("\n")


def load_body(path):
    lines = path.read_text(encoding="utf-8").splitlines()
    body = []
    for ln in lines:
        if ln.startswith("#"):
            continue
        body.append(ln)
    return "\n".join(body).strip()


def mix_text(real_text, synth_text, frac, n_words, seed, gen):
    rng = random.Random(seed * 50 + gen + int(frac * 1000))
    real_words = real_text.split()
    syn_words = synth_text.split()
    n_real = int(round(frac * n_words))
    n_syn = n_words - n_real
    if n_real > len(real_words):
        n_real = len(real_words)
        n_syn = n_words - n_real
    if n_real <= 0:
        real_part = []
    elif n_real >= len(real_words):
        real_part = real_words
    else:
        start = rng.randrange(0, len(real_words) - n_real + 1)
        real_part = real_words[start:start + n_real]
    if n_syn <= 0:
        syn_part = []
    elif not syn_words:
        syn_part = []
    else:
        acc = []
        while len(acc) < n_syn:
            acc.extend(syn_words)
        syn_part = acc[:n_syn]
    return " ".join(real_part + syn_part)


def run_generation(lang, regime, frac, gen, seed, train_text, real_d0, test_sents, tok,
                   temp, do_filter, prompt_words, n_layer, words, tag_note):
    key = key_of(lang, regime, frac, gen, seed, tok.vocab_size, temp, do_filter, prompt_words, n_layer, words)
    if key in DONE:
        return load_body(synth_path(key))
    t0 = time.time()
    model, loss, n_tokens, steps, train_secs = train_lm(tok, train_text, seed, gen, n_layer)
    bpc, lo, hi, n_sent = bpc_with_ci(model, tok, test_sents, seed, gen)
    gen_text, gen_secs = generate_text(
        model, tok, real_d0, temp, TOP_P, prompt_words, words, seed, gen
    )
    raw_text = gen_text
    used_text = filter_text(raw_text, lang) if do_filter else raw_text
    if word_count(used_text) < 20:
        used_text = raw_text
    m = text_metrics(raw_text, real_d0)
    m["script_purity"] = script_fraction(raw_text, lang)
    m["script_sentence_rate"] = script_sentence_rate(raw_text, lang)
    m["bpc"] = bpc
    m["bpc_ci_low"] = lo
    m["bpc_ci_high"] = hi
    m["bpc_sentences"] = n_sent
    m["train_loss"] = loss
    m["train_tokens"] = n_tokens
    m["train_steps"] = steps
    m["train_seconds"] = round(train_secs, 2)
    m["gen_seconds"] = round(gen_secs, 2)
    m["fertility"] = tok.fertility(real_d0)
    m["tokens_per_word_train"] = (n_tokens / float(word_count(train_text))) if word_count(train_text) else 0
    add_rows(lang, regime, frac, gen, seed, m, tok.vocab_size, temp, do_filter, prompt_words, n_layer, words)
    header = "# MODEL-GENERATED TEXT. not real %s. do not treat this as human writing.\n# %s\n# %s" % (
        lang, key, tag_note
    )
    save_text(synth_path(key), used_text if do_filter else raw_text, header)
    sample_lines = [ln for ln in raw_text.splitlines() if ln.strip()]
    if len(sample_lines) < 5:
        ww = raw_text.split()
        sample_lines = []
        for i in range(0, len(ww), 20):
            sample_lines.append(" ".join(ww[i:i + 20]))
    sample_lines = sample_lines[:500]
    sp = SAMP / (key + ".txt")
    save_text(sp, "\n".join(sample_lines), header + "\n# sample of generated text")
    mark_done(key)
    DONE.add(key)
    log("  %s %s f=%s gen %d seed %d  bpc %.3f  d1 %.3f  tail %.3f  script %.3f  (%.0fs)" % (
        lang, regime, frac, gen, seed, bpc, m["distinct1"], m["tail_retention"], m["script_purity"], time.time() - t0
    ))
    del model
    return used_text if do_filter else raw_text


def chain(lang, regime, frac, seed, real_d0, test_sents, tok, temp, do_filter, prompt_words,
          n_layer, words, fresh_chunks, n_gens):
    prev = None
    synths = []
    for gen in range(n_gens):
        if gen == 0:
            train_text = real_d0
        elif regime == "replace":
            train_text = prev
        elif regime == "accumulate":
            train_text = real_d0
            for s in synths:
                train_text = train_text + "\n" + s
        elif regime == "mix":
            train_text = mix_text(real_d0, prev, float(frac), words, seed, gen)
        elif regime == "fresh":
            if gen == 0:
                train_text = real_d0
            else:
                if gen - 1 >= len(fresh_chunks):
                    log("  skip fresh %s gen %d, no real chunk" % (lang, gen))
                    with open(FAIL_PATH, "a", encoding="utf-8") as f:
                        f.write("no fresh chunk %s gen %d\n" % (lang, gen))
                    break
                train_text = fresh_chunks[gen - 1]
        else:
            raise RuntimeError(regime)
        if word_count(train_text) < 50:
            with open(FAIL_PATH, "a", encoding="utf-8") as f:
                f.write("short train text %s %s gen %d\n" % (lang, regime, gen))
            log("  stop, short text %s %s gen %d" % (lang, regime, gen))
            break
        try:
            prev = run_generation(
                lang, regime, frac, gen, seed, train_text, real_d0, test_sents, tok,
                temp, do_filter, prompt_words, n_layer, words, regime,
            )
        except Exception as e:
            with open(FAIL_PATH, "a", encoding="utf-8") as f:
                f.write("%s %s f=%s gen %d seed %d ERROR %s\n" % (lang, regime, frac, gen, seed, e))
            log("  FAIL %s %s gen %d: %s" % (lang, regime, gen, e))
            break
        synths.append(prev)


def load_lang(lang, word_budget):
    train = sents_to_text(load_sents(CLEAN / (lang + "_train.txt")))
    train = take_words(train, word_budget)
    test = load_sents(CLEAN / (lang + "_test.txt"))
    fresh = []
    for k in (1, 2, 3):
        fp = CLEAN / ("%s_fresh%d.txt" % (lang, k))
        if fp.exists():
            fresh.append(take_words(sents_to_text(load_sents(fp)), word_budget))
    return train, test, fresh


def write_config(budget):
    text = "\n".join([
        "setting B, small transformer trained from scratch",
        "layers %d  embd %d  heads %d  block %d" % (N_LAYER, N_EMBD, N_HEAD, BLOCK),
        "batch %d  lr %s  epochs %d  min_steps_per_epoch %d" % (BATCH, LR, EPOCHS, MIN_STEPS_PER_EPOCH),
        "vocab target %d  temp %s  top_p %s  max_new_tokens %d" % (VOCAB, TEMP, TOP_P, MAX_NEW),
        "prompt_words %d  word_budget %d  seeds %s" % (PROMPT_WORDS, budget, SEEDS),
        "dropout 0",
        "each generation: new random init, seed*100+generation",
        "prompts always taken from the real D0, first %d words of each segment" % PROMPT_WORDS,
        "synthetic text is the continuation only, not the real prompt",
        "no filtering on the main runs",
        "machine: i5-11300H, 8GB ram, GTX 1650 4GB but torch is the cpu build",
    ])
    (RES / "config_used.txt").write_text(text + "\n", encoding="utf-8")


def phase_main(budget):
    for lang in LANGS:
        real, test, fresh = load_lang(lang, budget)
        tok = get_tokenizer(lang, real, VOCAB)
        for seed in SEEDS:
            log("MAIN %s replace seed %d" % (lang, seed))
            chain(lang, "replace", "0", seed, real, test, tok, TEMP, False, PROMPT_WORDS, N_LAYER, budget, fresh, GENS)
        log("MAIN %s accumulate seed %d" % (lang, SEEDS[0]))
        chain(lang, "accumulate", "0", SEEDS[0], real, test, tok, TEMP, False, PROMPT_WORDS, N_LAYER, budget, fresh, GENS)
        if lang in ("en", "te"):
            log("FRESH %s" % lang)
            chain(lang, "fresh", "1", SEEDS[0], real, test, tok, TEMP, False, PROMPT_WORDS, N_LAYER, budget, fresh, 4)


def phase_mix(budget):
    fracs = ["0.1", "0.2", "0.5"]
    for lang in LANGS:
        real, test, fresh = load_lang(lang, budget)
        tok = get_tokenizer(lang, real, VOCAB)
        for frac in fracs:
            log("MIX %s f=%s" % (lang, frac))
            chain(lang, "mix", frac, SEEDS[0], real, test, tok, TEMP, False, PROMPT_WORDS, N_LAYER, budget, fresh, GENS)


def phase_ablate(budget):
    half = max(800, budget // 2)
    jobs = [
        ("en", "replace", "0", 0.7, False, PROMPT_WORDS, N_LAYER, budget, VOCAB),
        ("hi", "replace", "0", 0.7, False, PROMPT_WORDS, N_LAYER, budget, VOCAB),
        ("en", "replace", "0", TEMP, True, PROMPT_WORDS, N_LAYER, budget, VOCAB),
        ("te", "replace", "0", TEMP, True, PROMPT_WORDS, N_LAYER, budget, VOCAB),
        ("en", "replace", "0", TEMP, False, PROMPT_WORDS, N_LAYER, half, VOCAB),
        ("te", "replace", "0", TEMP, False, PROMPT_WORDS, N_LAYER, half, VOCAB),
        ("en", "replace", "0", TEMP, False, 8, N_LAYER, budget, VOCAB),
        ("hi", "replace", "0", TEMP, False, 8, N_LAYER, budget, VOCAB),
        ("en", "replace", "0", TEMP, False, PROMPT_WORDS, 2, budget, VOCAB),
        ("te", "replace", "0", TEMP, False, PROMPT_WORDS, 2, budget, VOCAB),
    ]
    for lang, regime, frac, temp, do_filter, prompt_words, n_layer, words, vocab in jobs:
        real_full, test, fresh = load_lang(lang, budget)
        real = take_words(real_full, words)
        tok = get_tokenizer(lang, real, vocab)
        log("ABLATE %s temp=%s filt=%s prompt=%s L=%s words=%s" % (lang, temp, do_filter, prompt_words, n_layer, words))
        chain(lang, regime, frac, SEEDS[0], real, test, tok, temp, do_filter, prompt_words, n_layer, words, fresh, 4)


def phase_fertility(budget):
    for lang in ("hi", "te"):
        real, test, fresh = load_lang(lang, budget)
        for vocab in (300, 1400):
            tok = get_tokenizer(lang, real, vocab)
            log("FERT %s vocab %d (real %d) fertility %.3f" % (lang, vocab, tok.vocab_size, tok.fertility(real)))
            chain(lang, "replace", "0", SEEDS[0], real, test, tok, TEMP, False, PROMPT_WORDS, N_LAYER, budget, fresh, GENS)


def phase_smoke():
    budget = load_budget()
    real, test, _fresh = load_lang("en", budget)
    real_small = take_words(real, 800)
    tok = train_bpe(real_small, 200)
    log("smoke tokens %d fertility %.2f" % (len(tok.encode(real_small)), tok.fertility(real_small)))
    global EPOCHS, MIN_STEPS_PER_EPOCH
    old_e, old_m = EPOCHS, MIN_STEPS_PER_EPOCH
    EPOCHS = 2
    MIN_STEPS_PER_EPOCH = 10
    model, loss, n_tokens, steps, secs = train_lm(tok, real_small, 151, 0, 2)
    EPOCHS, MIN_STEPS_PER_EPOCH = old_e, old_m
    text, gsecs = generate_text(model, tok, real_small, 1.0, 0.95, 8, 80, 151, 0)
    bpc, lo, hi, n = bpc_with_ci(model, tok, test[:20], 151, 0)
    log("smoke loss %.3f steps %d train %.1fs gen %.1fs bpc %.3f" % (loss, steps, secs, gsecs, bpc))
    log("smoke sample: " + " ".join(text.split()[:40]))
    log("params %d" % model.n_params())


def main():
    global DONE
    DONE = read_done()
    cmd = sys.argv[1] if len(sys.argv) > 1 else "all"
    if cmd == "smoke":
        phase_smoke()
        return
    budget = load_budget()
    write_config(budget)
    log("budget %d words, torch %s, cuda %s" % (budget, torch.__version__, torch.cuda.is_available()))
    if cmd in ("main", "all"):
        phase_main(budget)
    if cmd in ("mix", "all"):
        phase_mix(budget)
    if cmd in ("ablate", "all"):
        phase_ablate(budget)
    if cmd in ("fert", "all"):
        phase_fertility(budget)
    log("finished " + cmd)


if __name__ == "__main__":
    main()
