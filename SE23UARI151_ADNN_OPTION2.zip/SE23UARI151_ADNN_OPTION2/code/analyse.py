# Akarshan Jogi, SE23UARI151

import csv
import math
from collections import defaultdict
from pathlib import Path

import numpy as np
from scipy.stats import spearmanr

ROOT = Path(__file__).resolve().parents[1]
CSV_PATH = ROOT / "results" / "runs.csv"
OUT = ROOT / "results" / "tables"
OUT.mkdir(parents=True, exist_ok=True)

LANGS = ["en", "hi", "mr", "te"]
NAMES = {"en": "English", "hi": "Hindi", "mr": "Marathi", "te": "Telugu"}
MAIN_WORDS = None
MAIN_VOCABS = None


def load_rows():
    rows = []
    with open(CSV_PATH, "r", encoding="utf-8") as f:
        for r in csv.DictReader(f):
            try:
                r["generation"] = int(r["generation"])
                r["seed"] = int(r["seed"])
                r["value"] = float(r["value"])
            except Exception:
                continue
            if math.isnan(r["value"]):
                continue
            rows.append(r)
    return rows


def is_main(r, word_budget=None, vocab_of=None):
    try:
        if int(r["filter"]) != 0:
            return False
        if abs(float(r["temp"]) - 1.0) > 1e-6:
            return False
        if int(r["prompt_words"]) != 16:
            return False
        if int(r["layers"]) != 3:
            return False
        if word_budget is not None and int(r["words"]) != int(word_budget):
            return False
        if vocab_of is not None and vocab_of.get(r["language"]) not in (None, str(r["vocab"])):
            return False
    except Exception:
        return False
    return True


def main_budget(rows):
    vals = []
    for r in rows:
        if r["metric"] == "bpc" and r["seed"] == 152 and r["regime"] == "replace":
            vals.append(int(float(r["words"])))
    return max(vals) if vals else None


def main_vocabs(rows):
    out = {}
    for r in rows:
        if r["metric"] == "bpc" and r["seed"] == 152 and r["generation"] == 0 and r["regime"] == "replace":
            out[r["language"]] = str(r["vocab"])
    return out


def group_metric(rows, regime, metric, frac=None, vocab=None, only_main=True, word_budget=None, vocab_of=None):
    bag = defaultdict(list)
    wb = MAIN_WORDS if word_budget is None else word_budget
    vo = MAIN_VOCABS if vocab_of is None else vocab_of
    for r in rows:
        if r["regime"] != regime or r["metric"] != metric:
            continue
        if only_main and not is_main(r, wb, vo):
            continue
        if frac is not None and str(r["fraction"]) != str(frac):
            continue
        if vocab is not None and str(r["vocab"]) != str(vocab):
            continue
        bag[(r["language"], r["generation"], r["seed"])].append(r["value"])
    per = {}
    for (lang, gen, seed), vals in bag.items():
        per[(lang, gen, seed)] = vals[-1]
    out = defaultdict(lambda: defaultdict(list))
    for (lang, gen, seed), v in per.items():
        out[lang][gen].append(v)
    return out


def mean_std(xs):
    if not xs:
        return float("nan"), float("nan")
    m = sum(xs) / float(len(xs))
    if len(xs) == 1:
        return m, 0.0
    var = sum((x - m) ** 2 for x in xs) / float(len(xs) - 1)
    return m, math.sqrt(var)


def rel_series(by_gen):
    if 0 not in by_gen:
        return {}
    base_m, _ = mean_std(by_gen[0])
    if base_m == 0 or math.isnan(base_m):
        return {}
    rel = {}
    for g, xs in by_gen.items():
        m, s = mean_std(xs)
        rel[g] = ((m - base_m) / abs(base_m), m, s)
    return rel


def slope_of(rel):
    pts = [(g, rel[g][0]) for g in sorted(rel)]
    if len(pts) < 2:
        return float("nan")
    xs = np.array([p[0] for p in pts], dtype=float)
    ys = np.array([p[1] for p in pts], dtype=float)
    b, a = np.polyfit(xs, ys, 1)
    return float(b)


def write_curves(rows):
    lines = []
    lines.append("relative change = (value - value_at_gen0) / abs(value_at_gen0)")
    lines.append("mean over seeds. sd is 0 when i only had one seed.")
    for regime in ("replace", "accumulate", "fresh"):
        for metric in ("bpc", "distinct1", "distinct2", "tail_retention", "rare_char_retention", "wordlen_js", "script_purity", "latin_word_rate"):
            grouped = group_metric(rows, regime, metric)
            if not grouped:
                continue
            lines.append("")
            lines.append("== %s  %s ==" % (regime, metric))
            lines.append("lang\tgen\tmean\tsd\trelative")
            for lang in LANGS:
                if lang not in grouped:
                    continue
                rel = rel_series(grouped[lang])
                for g in sorted(grouped[lang]):
                    m, s = mean_std(grouped[lang][g])
                    rv = rel.get(g, (float("nan"),))[0]
                    lines.append("%s\t%d\t%.4f\t%.4f\t%.4f" % (lang, g, m, s, rv))
                sl = slope_of(rel) if rel else float("nan")
                lines.append("%s\tslope\t%.4f" % (lang, sl))
    (OUT / "curves.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")


def collapse_table(rows):
    lines = ["regime\tlanguage\tmetric\tslope\tgen0_mean\tgen5_mean\tn_seeds_gen0"]
    for regime in ("replace", "accumulate"):
        for metric in ("bpc", "distinct1", "tail_retention", "rare_char_retention", "wordlen_js", "script_purity", "latin_word_rate"):
            grouped = group_metric(rows, regime, metric)
            for lang in LANGS:
                if lang not in grouped:
                    continue
                rel = rel_series(grouped[lang])
                sl = slope_of(rel) if rel else float("nan")
                g0 = mean_std(grouped[lang].get(0, []))[0]
                g5 = mean_std(grouped[lang].get(5, []))[0]
                nseeds = len(grouped[lang].get(0, []))
                lines.append("%s\t%s\t%s\t%.4f\t%.4f\t%.4f\t%d" % (regime, lang, metric, sl, g0, g5, nseeds))
    (OUT / "collapse_rates.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")


def regression(rows):
    grouped_seeds = defaultdict(list)
    for r in rows:
        if r["regime"] != "replace" or r["metric"] != "bpc":
            continue
        if not is_main(r, MAIN_WORDS, MAIN_VOCABS):
            continue
        grouped_seeds[(r["language"], r["generation"], r["seed"])].append(r["value"])
    base = {}
    for (lang, gen, seed), vals in grouped_seeds.items():
        if gen == 0:
            base[(lang, seed)] = vals[-1]
    ys = []
    gens = []
    langs = []
    for (lang, gen, seed), vals in grouped_seeds.items():
        b = base.get((lang, seed))
        if b is None or b == 0:
            continue
        ys.append((vals[-1] - b) / abs(b))
        gens.append(gen)
        langs.append(lang)
    if len(ys) < 8:
        (OUT / "regression.txt").write_text("not enough rows for the regression\n", encoding="utf-8")
        return
    n = len(ys)
    X = np.zeros((n, 8))
    y = np.array(ys, dtype=float)
    for i in range(n):
        X[i, 0] = 1.0
        X[i, 1] = gens[i]
        if langs[i] == "hi":
            X[i, 2] = 1.0
            X[i, 5] = gens[i]
        elif langs[i] == "mr":
            X[i, 3] = 1.0
            X[i, 6] = gens[i]
        elif langs[i] == "te":
            X[i, 4] = 1.0
            X[i, 7] = gens[i]
    coef, _, _, _ = np.linalg.lstsq(X, y, rcond=None)
    resid = y - X.dot(coef)
    dof = max(1, n - X.shape[1])
    sigma2 = float(np.sum(resid ** 2) / dof)
    try:
        xtx_inv = np.linalg.inv(X.T.dot(X))
        se = np.sqrt(np.clip(np.diag(xtx_inv) * sigma2, 0, None))
    except np.linalg.LinAlgError:
        se = np.array([float("nan")] * 8)
    labels = [
        "intercept",
        "gen (english slope)",
        "hindi offset",
        "marathi offset",
        "telugu offset",
        "gen x hindi (extra slope vs english)",
        "gen x marathi (extra slope vs english)",
        "gen x telugu (extra slope vs english)",
    ]
    lines = []
    lines.append("regression on the replace regime, relative bits-per-character.")
    lines.append("each row is one seed and one generation.")
    lines.append("n = %d" % n)
    lines.append("english is the baseline, so its extra slope is 0 by construction.")
    lines.append("")
    lines.append("term\tcoef\tse\tt")
    for lab, c, s in zip(labels, coef, se):
        t = c / s if s and s > 0 else float("nan")
        lines.append("%s\t%.4f\t%.4f\t%.2f" % (lab, c, s, t))
    lines.append("")
    lines.append("how to read the interaction: if gen x hindi is positive, hindi's bits-per-character")
    lines.append("gets worse faster than english, per generation. a t above about 2 is a rough")
    lines.append("hint, not a proof. six generations is a small sample.")
    (OUT / "regression.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")


def fertility_table(rows):
    bag_f = defaultdict(list)
    bag_b = defaultdict(list)
    for r in rows:
        if r["regime"] != "replace":
            continue
        if int(r["filter"]) != 0 or abs(float(r["temp"]) - 1.0) > 1e-6:
            continue
        if int(r["prompt_words"]) != 16 or int(r["layers"]) != 3:
            continue
        if MAIN_WORDS is not None and int(float(r["words"])) != int(MAIN_WORDS):
            continue
        if r["metric"] == "fertility" and r["generation"] == 0 and r["seed"] == 151:
            bag_f[(r["language"], r["vocab"])].append(r["value"])
        if r["metric"] == "bpc":
            bag_b[(r["language"], r["vocab"], r["generation"], r["seed"])].append(r["value"])
    lines = ["language\tvocab\tfertility\tbpc_slope\tgen0\tgen5"]
    points = []
    keys = sorted(set((lang, vocab) for (lang, vocab, _g, _s) in bag_b))
    for lang, vocab in keys:
        series = {}
        for (l, v, g, s), vals in bag_b.items():
            if l == lang and v == vocab and s == 151:
                series[g] = vals[-1]
        if 0 not in series or len(series) < 3:
            continue
        base = series[0]
        rel = {g: ((series[g] - base) / abs(base), series[g], 0) for g in series}
        sl = slope_of(rel)
        fert = bag_f.get((lang, vocab), [float("nan")])[-1]
        g5 = series.get(5, float("nan"))
        lines.append("%s\t%s\t%.4f\t%.4f\t%.4f\t%.4f" % (lang, vocab, fert, sl, base, g5))
        if not math.isnan(fert):
            points.append((fert, sl, lang, vocab))
    extra = ""
    if len(points) >= 3:
        rho, p = spearmanr([a for a, _b, _l, _v in points], [b for _a, b, _l, _v in points])
        extra = "\nspearman rho = %.3f  p = %.3f  n = %d\n" % (rho, p, len(points))
        extra += "n is small. i am not treating this p-value as a strong claim.\n"
        rng = np.random.RandomState(151)
        boots = []
        arr = np.array(points, dtype=object)
        for _ in range(1000):
            idx = rng.randint(0, len(points), size=len(points))
            xs = [points[i][0] for i in idx]
            ys = [points[i][1] for i in idx]
            if len(set(np.round(xs, 5))) < 2:
                continue
            r, _ = spearmanr(xs, ys)
            if not math.isnan(r):
                boots.append(r)
        if boots:
            boots.sort()
            lo = boots[int(0.025 * (len(boots) - 1))]
            hi = boots[int(0.975 * (len(boots) - 1))]
            extra += "bootstrap 95%% interval for rho: %.3f to %.3f\n" % (lo, hi)
    (OUT / "fertility.txt").write_text("\n".join(lines) + "\n" + extra, encoding="utf-8")


def safe_fraction(rows):
    metrics = ["bpc", "distinct1", "distinct2", "tail_retention", "rare_char_retention", "wordlen_js"]
    fracs = [("replace", "0"), ("mix", "0.05"), ("mix", "0.1"), ("mix", "0.2"), ("mix", "0.5")]
    lines = ["language\tfraction\t" + "\t".join(m + "_rel" for m in metrics) + "\tall_within_5pct"]
    verdict = {lang: None for lang in LANGS}
    for lang in LANGS:
        for regime, frac in fracs:
            rels = []
            ok = True
            missing = False
            for metric in metrics:
                grouped = group_metric(rows, regime, metric, frac=frac)
                if lang not in grouped or 0 not in grouped[lang] or 5 not in grouped[lang]:
                    rels.append("NA")
                    missing = True
                    ok = False
                    continue
                rel = rel_series(grouped[lang])
                rv = rel.get(5, (float("nan"),))[0]
                rels.append("%.3f" % rv)
                if math.isnan(rv) or abs(rv) > 0.05:
                    ok = False
            lines.append("%s\t%s\t%s\t%s" % (lang, frac, "\t".join(rels), "yes" if ok else "no"))
            if ok and verdict[lang] is None and not missing:
                verdict[lang] = frac
    lines.append("")
    for lang in LANGS:
        v = verdict[lang]
        if v is None:
            lines.append("%s safe fraction: none of the fractions i tried kept every metric within 5%% at generation 5" % NAMES[lang])
        else:
            lines.append("%s safe fraction: %s" % (NAMES[lang], v))
    (OUT / "safe_fraction.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")


def ablation_table(rows):
    lines = ["language\twhat\tbpc_gen0\tbpc_last\ttail_gen0\ttail_last\tlast_gen"]
    bag = defaultdict(list)
    for r in rows:
        if r["regime"] != "replace":
            continue
        if r["metric"] not in ("bpc", "tail_retention", "distinct1", "script_purity"):
            continue
        if r["seed"] != 151:
            continue
        tag = "main"
        if int(r["filter"]) == 1:
            tag = "filter"
        elif abs(float(r["temp"]) - 0.7) < 1e-6:
            tag = "temp0.7"
        elif int(r["prompt_words"]) == 8:
            tag = "prompt8"
        elif int(r["layers"]) == 2:
            tag = "layers2"
        else:
            tag = "words" + str(r["words"])
        if tag == "main" and int(r["layers"]) != 3:
            continue
        if tag.startswith("words") and MAIN_VOCABS and MAIN_VOCABS.get(r["language"]) not in (None, str(r["vocab"])):
            continue
        bag[(r["language"], tag, r["metric"], r["generation"])].append(r["value"])
    seen = set((a, b) for (a, b, _m, _g) in bag)
    for lang, tag in sorted(seen):
        for metric in ("bpc", "tail_retention"):
            gens = sorted(g for (l, t, m, g) in bag if l == lang and t == tag and m == metric)
            if not gens:
                continue
        b0 = bag.get((lang, tag, "bpc", 0), [float("nan")])[-1]
        t0 = bag.get((lang, tag, "tail_retention", 0), [float("nan")])[-1]
        gens = sorted(g for (l, t, m, g) in bag if l == lang and t == tag and m == "bpc")
        last = 3 if 3 in gens else (gens[-1] if gens else None)
        if last is None:
            continue
        bl = bag.get((lang, tag, "bpc", last), [float("nan")])[-1]
        tl = bag.get((lang, tag, "tail_retention", last), [float("nan")])[-1]
        lines.append("%s\t%s\t%.4f\t%.4f\t%.4f\t%.4f\t%d" % (lang, tag, b0, bl, t0, tl, last))
    (OUT / "ablation.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")


def main():
    if not CSV_PATH.exists():
        raise SystemExit("no results yet")
    global MAIN_WORDS, MAIN_VOCABS
    rows = load_rows()
    MAIN_WORDS = main_budget(rows)
    MAIN_VOCABS = main_vocabs(rows)
    write_curves(rows)
    collapse_table(rows)
    regression(rows)
    fertility_table(rows)
    safe_fraction(rows)
    ablation_table(rows)
    print("wrote tables to", OUT)


if __name__ == "__main__":
    main()
