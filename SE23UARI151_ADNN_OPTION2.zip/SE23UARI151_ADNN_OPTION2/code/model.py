# Akarshan Jogi, SE23UARI151

import torch
import torch.nn as nn
import torch.nn.functional as F


class Block(nn.Module):
    def __init__(self, n_embd, n_head):
        super(Block, self).__init__()
        self.attn = nn.MultiheadAttention(n_embd, n_head, batch_first=True)
        self.ln1 = nn.LayerNorm(n_embd)
        self.ln2 = nn.LayerNorm(n_embd)
        self.fc1 = nn.Linear(n_embd, 4 * n_embd)
        self.fc2 = nn.Linear(4 * n_embd, n_embd)

    def forward(self, x):
        t = x.size(1)
        h = self.ln1(x)
        mask = torch.triu(torch.full((t, t), float("-inf"), device=x.device), 1)
        a, _ = self.attn(h, h, h, attn_mask=mask, need_weights=False)
        x = x + a
        h = self.ln2(x)
        x = x + self.fc2(F.gelu(self.fc1(h)))
        return x


class TinyGPT(nn.Module):
    def __init__(self, vocab, n_embd, n_head, n_layer, block):
        super(TinyGPT, self).__init__()
        self.block = block
        self.vocab = vocab
        self.tok = nn.Embedding(vocab, n_embd)
        self.pos = nn.Embedding(block, n_embd)
        self.layers = nn.ModuleList([Block(n_embd, n_head) for _ in range(n_layer)])
        self.ln = nn.LayerNorm(n_embd)
        self.head = nn.Linear(n_embd, vocab, bias=False)
        self.head.weight = self.tok.weight

    def forward(self, idx):
        if idx.size(1) > self.block:
            idx = idx[:, -self.block:]
        t = idx.size(1)
        pos = torch.arange(t, device=idx.device)
        x = self.tok(idx) + self.pos(pos)[None, :, :]
        for layer in self.layers:
            x = layer(x)
        x = self.ln(x)
        return self.head(x)

    def n_params(self):
        return sum(p.numel() for p in self.parameters())


def sample_top_p(logits, temp, top_p):
    if temp <= 0:
        return torch.argmax(logits, dim=-1)
    logits = logits / temp
    probs = torch.softmax(logits, dim=-1)
    sorted_probs, sorted_idx = torch.sort(probs, descending=True, dim=-1)
    cum = torch.cumsum(sorted_probs, dim=-1)
    remove = cum > top_p
    remove[:, 1:] = remove[:, :-1].clone()
    remove[:, 0] = False
    sorted_probs = sorted_probs.masked_fill(remove, 0.0)
    denom = sorted_probs.sum(dim=-1, keepdim=True)
    denom = torch.clamp(denom, min=1e-12)
    sorted_probs = sorted_probs / denom
    choice = torch.multinomial(sorted_probs, num_samples=1)
    return sorted_idx.gather(-1, choice).squeeze(-1)
